package com.example.fecapay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MenuActivity extends AppCompatActivity {

    private Button btnPerfil, btnRecarga, btnTransacoes, btnBoletos, btnAjuda, btnInicio, btnAsa, btnSair;
    private ImageView btnFecharAviso;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu); // Altere para o nome real do XML, se for diferente

        // Inicializa os botões
        btnPerfil = findViewById(R.id.btn_perfil);
        btnRecarga = findViewById(R.id.btn_recarga);
        btnTransacoes = findViewById(R.id.btn_transacoes);
        btnBoletos = findViewById(R.id.btn_boletos);
        btnAjuda = findViewById(R.id.btn_ajuda);
        btnInicio = findViewById(R.id.btn_inicio);
        btnAsa = findViewById(R.id.btn_asa);
        btnSair = findViewById(R.id.btn_sair);
        btnFecharAviso = findViewById(R.id.btn_fechar);

        // Ações: vão para PerfilActivity
        View.OnClickListener perfilRedirect = v -> startActivity(new Intent(MenuActivity.this, PerfilActivity.class));
        btnPerfil.setOnClickListener(perfilRedirect);
        btnTransacoes.setOnClickListener(perfilRedirect);
        btnInicio.setOnClickListener(perfilRedirect);

        // Recarga -> BoletosActivity
        btnRecarga.setOnClickListener(v -> startActivity(new Intent(MenuActivity.this, BoletosActivity.class)));

        // Boletos -> BoletosActivity
        btnBoletos.setOnClickListener(v -> startActivity(new Intent(MenuActivity.this, BoletosActivity.class)));

        // ASA e Ajuda -> AjudaActivity
        btnAjuda.setOnClickListener(v -> startActivity(new Intent(MenuActivity.this, AjudaActivity.class)));
        btnAsa.setOnClickListener(v -> startActivity(new Intent(MenuActivity.this, AjudaActivity.class)));

        // Sair -> volta para LoginActivity (desloga o usuário)
        btnSair.setOnClickListener(v -> {
            Intent intent = new Intent(MenuActivity.this, LoginActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });

        // Botão de fechar o aviso (esconde o card com a imagem)
        btnFecharAviso.setOnClickListener(v -> {
            View cardAviso = findViewById(R.id.card_aviso);
            cardAviso.setVisibility(View.GONE);
        });
    }
}
