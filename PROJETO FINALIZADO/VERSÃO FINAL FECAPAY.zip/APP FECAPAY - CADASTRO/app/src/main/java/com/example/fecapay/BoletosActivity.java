package com.example.fecapay;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class BoletosActivity extends AppCompatActivity {

    private EditText editRA, editValor;
    private Button btnCartao, btnCopiarCodigo;
    private DatabaseHelper dbHelper;

    private static final double VALOR_BOLETO = 1425.00;  // valor fixo do boleto

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_boletos);

        dbHelper = new DatabaseHelper(this);

        editRA = findViewById(R.id.editRA);
        editValor = findViewById(R.id.editValor);
        btnCartao = findViewById(R.id.btnCartao);
        btnCopiarCodigo = findViewById(R.id.btnCopiarCodigo);

        // Botão de pagamento do boleto
        btnCopiarCodigo.setOnClickListener(v -> realizarPagamentoBoleto());

        // Botão de adicionar saldo
        btnCartao.setOnClickListener(v -> adicionarSaldo());
    }

    private void realizarPagamentoBoleto() {
        String ra = editRA.getText().toString();

        if (ra.isEmpty()) {
            Toast.makeText(this, "Informe o RA do usuário", Toast.LENGTH_SHORT).show();
            return;
        }

        double saldoAtual = dbHelper.getSaldoUsuario(ra);

        if (saldoAtual >= VALOR_BOLETO) {
            double novoSaldo = saldoAtual - VALOR_BOLETO;
            dbHelper.atualizarSaldo(ra, novoSaldo);
            salvarSaldoNoSharedPreferences(novoSaldo);
            Toast.makeText(this, "Pagamento realizado com sucesso!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Saldo insuficiente!", Toast.LENGTH_SHORT).show();
        }
    }

    private void adicionarSaldo() {
        String ra = editRA.getText().toString();
        String valorStr = editValor.getText().toString();

        if (ra.isEmpty() || valorStr.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            double valor = Double.parseDouble(valorStr);
            double saldoAtual = dbHelper.getSaldoUsuario(ra);
            double novoSaldo = saldoAtual + valor;
            dbHelper.atualizarSaldo(ra, novoSaldo);
            salvarSaldoNoSharedPreferences(novoSaldo);
            Toast.makeText(this, "Saldo adicionado com sucesso!", Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Valor inválido", Toast.LENGTH_SHORT).show();
        }
    }

    private void salvarSaldoNoSharedPreferences(double saldo) {
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putFloat("saldo_usuario", (float) saldo);
        editor.apply();
    }
}
