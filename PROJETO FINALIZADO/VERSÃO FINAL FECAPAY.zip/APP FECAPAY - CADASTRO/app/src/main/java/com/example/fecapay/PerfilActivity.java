package com.example.fecapay;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PerfilActivity extends AppCompatActivity {

    private TextView tvGreeting, tvBalance;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // 1. Recuperar o nome enviado por Intent
        String nomeUsuario = getIntent().getStringExtra("nome_usuario");

        // 2. Referenciar os TextViews
        tvGreeting = findViewById(R.id.tv_greeting);
        tvBalance = findViewById(R.id.tv_balance);

        // 3. Atualizar o texto com o nome
        if (nomeUsuario != null && !nomeUsuario.isEmpty()) {
            tvGreeting.setText("Olá " + nomeUsuario + "!");
        } else {
            tvGreeting.setText("Olá!");
        }

        // 4. Buscar saldo no SharedPreferences
        SharedPreferences prefs = getSharedPreferences("user_data", MODE_PRIVATE);
        float saldo = prefs.getFloat("saldo_usuario", 0.0f);

        // 5. Mostrar saldo formatado
        tvBalance.setText(String.format("Saldo: R$ %.2f", saldo));
    }
}
