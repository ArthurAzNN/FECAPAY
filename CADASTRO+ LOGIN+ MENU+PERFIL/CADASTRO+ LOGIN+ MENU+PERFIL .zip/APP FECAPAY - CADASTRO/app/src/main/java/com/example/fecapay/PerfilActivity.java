package com.example.fecapay;


import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class PerfilActivity extends AppCompatActivity {

    private TextView tvGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        // 1. Recuperar o nome enviado por Intent
        String nomeUsuario = getIntent().getStringExtra("nome_usuario");

        // 2. Referenciar o TextView da saudação
        tvGreeting = findViewById(R.id.tv_greeting);

        // 3. Atualizar o texto com o nome
        if (nomeUsuario != null && !nomeUsuario.isEmpty()) {
            tvGreeting.setText("Olá " + nomeUsuario + "!");
        } else {
            tvGreeting.setText("Olá!");
        }
    }
}
